package oneToMany;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class QuestionAnswerMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sf=new Configuration().configure().buildSessionFactory();
		Session ses=sf.openSession();
/*		
		Transaction tx=ses.beginTransaction();
		Question q=new Question("What is Servlet");
		Answer ans1=new Answer("Servlet is SSPL", "Amit");
		Answer ans2=new Answer("Servlet is shfhf", "Ankit");
		Answer ans3=new Answer("Servlet is higigig", "Ankush");
		List<Answer> li=new ArrayList<Answer>();
		li.add(ans1);
		li.add(ans2);
		li.add(ans3);
		q.setAnswer(li);
		ses.save(q);
		tx.commit();*/
		
/*		Question q=ses.get(Question.class,1);
		System.out.println(q.getqName());
		ses.evict(q);
		q.getAnswer().forEach(a->{System.out.println(a.getAns());});*/
		
		Answer a=ses.get(Answer.class, 3);
		System.out.println(a.getAns());
		System.out.println(a.getQues().getqName());
		
		System.out.println("Done!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		ses.close();
		sf.close();
		
	}

}
