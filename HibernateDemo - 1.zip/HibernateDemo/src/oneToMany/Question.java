package oneToMany;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "QuestionTable")
public class Question {
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	private int qid;
	@Column(name = "Question_Name")
	private String qName;
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Answer> answer;

	public Question() {
		// TODO Auto-generated constructor stub
	}

	public int getQid() {
		return qid;
	}

	public void setQid(int qid) {
		this.qid = qid;
	}

	public String getqName() {
		return qName;
	}

	public void setqName(String qName) {
		this.qName = qName;
	}

	public List<Answer> getAnswer() {
		return answer;
	}

	public void setAnswer(List<Answer> answer) {
		this.answer = answer;
	}

	public Question(String qName) {
		super();
		this.qName = qName;

	}

}
