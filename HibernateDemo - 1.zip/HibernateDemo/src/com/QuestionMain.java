package com;

import java.util.HashMap;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class QuestionMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sf=new Configuration().configure().buildSessionFactory();
		Session ses=sf.openSession();
		
		Transaction tx=ses.beginTransaction();
		Map<Integer,String> m=new HashMap<Integer,String>();
		m.put(1,"Java is OOPS");
		m.put(2, "Java is PI");
		Question q=new Question(101,"What is Java",m);
		ses.save(q);
		
		tx.commit();
		System.out.println("Saved!!!!!!!!");
		ses.close();
		sf.close();
		
	}

}
