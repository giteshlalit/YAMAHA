package com;

import java.util.Map;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;

@Entity
public class Question {
	@Id
	private int qid;
	@Column(name="QuestionName")
	private String qname;
	@ElementCollection
	@CollectionTable(name="Answer",joinColumns= @JoinColumn(name="qid"))
	@MapKeyColumn(name = "AnswerID")
	@Column(name = "AnswerName")
	private Map<Integer,String> answer;
	
	public int getQid() {
		return qid;
	}
	public void setQid(int qid) {
		this.qid = qid;
	}
	public String getQname() {
		return qname;
	}
	public void setQname(String qname) {
		this.qname = qname;
	}
	public Map<Integer, String> getAnswer() {
		return answer;
	}
	public void setAnswer(Map<Integer, String> answer) {
		this.answer = answer;
	}
	public Question(int qid, String qname, Map<Integer, String> answer) {
		super();
		this.qid = qid;
		this.qname = qname;
		this.answer = answer;
	}
	
	
	
	
	
	
}
