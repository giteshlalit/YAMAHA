package com;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Customer {
@Id
private int customerId;
private String name;
@Temporal(TemporalType.DATE)
private Date dob;

@OneToOne(cascade=CascadeType.ALL)				//ownership to customer
@JoinColumn(name = "aid")
private Address address;

public Customer()
{
	
}

public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Date getDob() {
	return dob;
}
public void setDob(Date dob) {
	this.dob = dob;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}
public Customer(int customerId, String name, Date dob, Address address) {
	super();
	this.customerId = customerId;
	this.name = name;
	this.dob = dob;
	this.address = address;
}


}
