package com;

import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.ymsli.bean.Student;

public class CustomerMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sf=new Configuration().configure().buildSessionFactory();
		Session ses=sf.openSession();
		
/*		Transaction tx=ses.beginTransaction();
		Address a=new Address(14, "Dhanbad", "india", "120496");
		Customer c=new Customer(105, "Abhishek", new Date(), a);
		ses.save(a);
		ses.save(c);
		
		tx.commit();*/
		
	/*	Customer cu=ses.get(Customer.class, 100);
		System.out.println(cu.getCustomerId()+" "+cu.getName()+" "+cu.getAddress().getAid()+" "+cu.getAddress().getCity());*/
/*		
		Query q=ses.createQuery("from Customer cu");
		List<Customer> li=q.getResultList();
		for(Customer c:li)
		{
			System.out.println(c.getCustomerId()+"\t"+c.getAddress().getAid()+"\t"+c.getName());
		}*/
//		System.out.println("Saved!!!!");
		
		Transaction tx=ses.beginTransaction();
		Address a=new Address(14, "Dhanbad", "india", "120496");
		Customer c=new Customer(105, "Abhishek", new Date(), a);
	
		ses.save(c);

		tx.commit();
		System.out.println("Saved!!!!");
		ses.close();
		sf.close();
	}

}
