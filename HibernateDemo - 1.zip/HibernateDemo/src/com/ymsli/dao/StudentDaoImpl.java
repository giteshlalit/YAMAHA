package com.ymsli.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ymsli.bean.Student;
import com.ymsli.config.MySession;

public class StudentDaoImpl implements StudentDao{
SessionFactory sf=MySession.getSession();
	@Override
	public String deleteStudent(String sid) {
		Session ses=sf.openSession();
		Student st=ses.get(Student.class, sid);
		if(st!=null)
		{
		System.out.println(st.getName());
		org.hibernate.Transaction tx=ses.beginTransaction();
		ses.delete(st);
		tx.commit();
		ses.close();
		return "Deleted";
		}
		else
			return "Student Not Found";
	}

	@Override
	public List<Student> getAll() {
		// TODO Auto-generated method stub
		Session ses=sf.openSession();
		
		Query q=ses.createQuery("from Student s");
		List<Student> li=q.getResultList();
		
		
		return li;
	}

}
