package com.ymsli.dao;

import java.util.List;

import com.ymsli.bean.Student;

public interface StudentDao {
public String deleteStudent(String sid);
public List<Student> getAll();
}
