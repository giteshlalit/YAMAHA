package com.ymsli.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Student {
	@Id
	private String sid;
	private String name;
	private String city;
	private int marks;
	
	public Student()
	{
		
	}
	
	public Student(String sid, String name, String city, int marks) {
		super();
		this.sid = sid;
		this.name = name;
		this.city = city;
		this.marks = marks;
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
}
