package com.ymsli.main;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.ymsli.bean.Student;
import com.ymsli.dao.StudentDao;
import com.ymsli.dao.StudentDaoImpl;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*		SessionFactory sf=new Configuration().configure().buildSessionFactory();
		Session ses=sf.openSession();
		
		Transaction tx=ses.beginTransaction();
		Student s=new Student("1003","Avinash","bharatpur",78);
		ses.save(s);
		
		tx.commit();
		System.out.println("Student saved ho gya ji!!!!!!!!!!!!!");
		ses.close();
		sf.close();*/
		
		StudentDao sd=new StudentDaoImpl();
	//	sd.deleteStudent("1002");
		
		List<Student> li=sd.getAll();
		for(Student l:li)
		{
			System.out.println(l.getSid()+"\t"+l.getName()+"\t"+l.getCity()+"\t"+l.getMarks());
		}
		
	}
                                                                             
}
