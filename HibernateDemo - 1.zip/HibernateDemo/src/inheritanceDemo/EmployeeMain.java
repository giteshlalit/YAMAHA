package inheritanceDemo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmployeeMain {

	public static void main(String[] args) {
	SessionFactory sf=new Configuration().configure().buildSessionFactory();
	Session ses=sf.openSession();
	Transaction tx=ses.beginTransaction();
	/*RegularEmployee remp=n        
	 * ew RegularEmployee();
	//ContractEmployee c=new ContractEmployee();
	remp.setEmpid(1002);
	remp.setName("Ankit");
	remp.setSalary(10000);
	remp.setPf(19000);
	//c.setPay_per_day(1000);
	ses.save(remp);
	tx.commit();*/
	
	
	RegularEmployee res=ses.get(RegularEmployee.class, 1002);
	System.out.println(res.getName());
	System.out.println(res.getSalary());
	ses.close();
	System.out.println("Done!!!!!!!!!!!!!!!!!!!");
	sf.close();
	}

}
