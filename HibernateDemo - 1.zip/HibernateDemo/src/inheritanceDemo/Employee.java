package inheritanceDemo;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name="Emp12345")
@Inheritance(strategy=InheritanceType.JOINED)
//@DiscriminatorColumn(name="EmployeeType",discriminatorType=DiscriminatorType.STRING)
//@DiscriminatorValue(value="emp")
public class Employee {
@Id
private int empid;
private String name;
public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}


}
