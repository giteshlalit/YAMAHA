package inheritanceDemo;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
//@DiscriminatorValue(value="ContEmployee")
@Table(name="Contract12345")
/*@AttributeOverrides({
	@AttributeOverride(name = "empid",column= @Column(name="EmployeeID")),
	@AttributeOverride(name = "name",column= @Column(name="EmployeeName")),
})*/
@PrimaryKeyJoinColumn(name = "empid")
public class ContractEmployee extends Employee {
	private double pay_per_day;

	public double getPay_per_day() {
		return pay_per_day;
	}

	public void setPay_per_day(double pay_per_day) {
		this.pay_per_day = pay_per_day;
	}
	
}
