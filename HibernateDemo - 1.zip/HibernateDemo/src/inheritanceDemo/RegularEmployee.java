package inheritanceDemo;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
//@DiscriminatorValue(value="RegEmployee")
@Table(name="Reg12345")
/*@AttributeOverrides({
	@AttributeOverride(name = "empid",column= @Column(name="EmployeeID")),
	@AttributeOverride(name = "name",column= @Column(name="EmployeeName")),
})*/
@PrimaryKeyJoinColumn(name = "empid")
public class RegularEmployee extends Employee {
	private double salary;
	@Column(name="Provident_Fund")
	private double pf;
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public double getPf() {
		return pf;
	}
	public void setPf(double pf) {
		this.pf = pf;
	}
	
}
