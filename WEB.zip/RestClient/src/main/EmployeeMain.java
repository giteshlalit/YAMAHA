package main;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class EmployeeMain {

	public static void main(String[] args) throws ClientProtocolException, IOException, JAXBException, ParserConfigurationException, SAXException {
		
		HttpClient client=HttpClients.createDefault();
		HttpGet req=new HttpGet("http://10.167.23.127:8080/RestExampleMaven1/employee");
		req.addHeader("accept", "application/xml");
		
		HttpResponse res=client.execute(req);
		InputStreamReader isr=new InputStreamReader(res.getEntity().getContent());
		BufferedReader br=new BufferedReader(isr);				//to read line by line
		String result=br.readLine();

	/*	 JAXBContext jc = JAXBContext.newInstance(Employee.class); 
		    Unmarshaller u = jc.createUnmarshaller();    
            Employee emp=(Employee) u.unmarshal(new StringReader(result));
            //it require only reader type object
*/    
          //  System.out.println(emp.getEmpid()+"\t"+emp.getName()+"\t"+emp.getAge()+"\t"+emp.getSalary()+"\t"+emp.getAddress());
	
		DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();
		DocumentBuilder db=dbf.newDocumentBuilder();
		Document doc=db.parse(new InputSource(new ByteArrayInputStream(result.getBytes())));
		doc.getDocumentElement().normalize();
		System.out.println(doc.getDocumentElement().getNodeName());
		NodeList nList = doc.getElementsByTagName("employee");
		for(int i=0;i<nList.getLength();i++)
		{
			Node n=nList.item(i);
			Element e=(Element)n;
			String empid=e.getElementsByTagName("empid").item(0).getTextContent();
			String name=e.getElementsByTagName("name").item(0).getTextContent();
			String age=e.getElementsByTagName("age").item(0).getTextContent();
			String salary=e.getElementsByTagName("salary").item(0).getTextContent();
			String address=e.getElementsByTagName("address").item(0).getTextContent();
			System.out.println(empid+"\t"+name+"\t"+age+"\t"+salary+"\t"+address);
			
			
		}
		
	}

}
