package main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;

public class EmployeeMain1 {

	public static void main(String[] args) throws ClientProtocolException, IOException, JAXBException {
		// TODO Auto-generated method stub
		HttpClient client=HttpClients.createDefault();
		HttpGet req=new HttpGet("http://10.167.23.127:8080/RestExampleMaven1/employee");
		req.addHeader("accept", "application/xml");
		
		HttpResponse res=client.execute(req);
		InputStreamReader isr=new InputStreamReader(res.getEntity().getContent());
		BufferedReader br=new BufferedReader(isr);				//to read line by line
		String result=br.readLine();
		
		
		JAXBContext jc = JAXBContext.newInstance(Employees.class); 
	    Unmarshaller u = jc.createUnmarshaller();    
        Employees emp2=(Employees) u.unmarshal(new StringReader(result));
        //it require only reader type object
        List<Employee> li=emp2.getEmployee();
        for(Employee emp:li)
        {
        System.out.println(emp.getEmpid()+"\t"+emp.getName()+"\t"+emp.getAge()+"\t"+emp.getSalary()+"\t"+emp.getAddress());
        }
        }

}
