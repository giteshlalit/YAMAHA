package main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;


import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;


import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;

import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.Gson;

public class EmployeeMain2 {

	public static void main(String[] args) throws JAXBException, ClientProtocolException, IOException {
		// TODO Auto-generated method stub
		

	     
		Employee e=new Employee("Mo140", "Mohit", 18, 45000, "DLI");
		
/*	    JAXBContext jc = JAXBContext.newInstance(Employee.class);
	    Marshaller m = jc.createMarshaller();

	    StringWriter writer = new StringWriter();
	    m.marshal(e, writer);*/
	    
/*	    HttpClient client=HttpClients.createDefault();
		HttpPost req=new HttpPost("http://10.167.23.127:8080/RestExampleMaven1/employee");
		req.addHeader("content-type", "application/json");
		StringEntity se=new StringEntity("{\"empid\":\"Sk140\",\"name\":\"Sakib\",\"age\":\"40\",\"salary\":\"2000\",\"address\":\"patna\"} ");
		req.setEntity(se);
		HttpResponse res=client.execute(req);
		System.out.println(res);*/
		
/*		InputStreamReader isr=new InputStreamReader(res.getEntity().getContent());
		BufferedReader br=new BufferedReader(isr);				//to read line by line
		String result=br.readLine();*/
		
/*		JSONObject jo=new JSONObject();
		jo.put("empid", "Ka140");
		jo.put("name", "karan");
		jo.put("age", "18");
		jo.put("salary", "44000");
		jo.put("address", "noida");
		HttpClient client=HttpClients.createDefault();
		HttpPost req=new HttpPost("http://10.167.23.127:8080/RestExampleMaven1/employee");
		req.addHeader("content-type", "application/json");
		StringEntity se=new StringEntity(jo.toJSONString());	
		req.setEntity(se);
		HttpResponse res=client.execute(req);
		System.out.println(res);*/

	/*    Unmarshaller u = jc.createUnmarshaller();    
        Employee emp=(Employee) u.unmarshal(new StringReader(result));
        //it require only reader type object
       

        System.out.println(emp.getEmpid()+"\t"+emp.getName()+"\t"+emp.getAge()+"\t"+emp.getSalary()+"\t"+emp.getAddress());
        */
		Gson ob=new Gson();
		String s=ob.toJson(e);
		HttpClient client=HttpClients.createDefault();
		HttpPost req=new HttpPost("http://10.167.23.127:8080/RestExampleMaven1/employee");
		req.addHeader("content-type", "application/json");
		StringEntity se=new StringEntity(s);
		req.setEntity(se);
		HttpResponse res=client.execute(req);
		System.out.println(res);
	}

}
