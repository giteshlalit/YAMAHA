package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.HelloWorld;

public class HelloMain {

	public static void main(String[] args) {
/*	HelloWorld ob=new HelloWorld();
	ob.setName("amit"); 	*/					//Manual Dependancy Injection
		
	ApplicationContext ctx=new ClassPathXmlApplicationContext("Bean.xml");	//call ioc container,all dependency managed by spring
	HelloWorld ob=(HelloWorld)ctx.getBean("hello");
	System.out.println(ob.sayHello());
	
	HelloWorld ob1=(HelloWorld)ctx.getBean("hello");
	System.out.println(ob1.sayHello());
	ob1.setName("Avinash");
	System.out.println(ob.sayHello());
	System.out.println(ob1.sayHello()); 
	}

}
