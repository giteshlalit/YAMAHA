package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.Employee;
import com.HelloWorld;

public class EmployeeMain {

	public static void main(String[] args) {
/*	Employee e=new Employee();
	e.printEmployee();*/
		ApplicationContext ctx=new ClassPathXmlApplicationContext("Bean.xml");	
		Employee e=(Employee)ctx.getBean("emp");
		e.printEmployee();
		
		
	}

}
