package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sf=new Configuration().configure().buildSessionFactory();
		Session ses=sf.openSession();
		
		Transaction tx=ses.beginTransaction();
		Student s=new Student("1001","Gitesh","Delhi",78);
		ses.save(s);
		tx.commit();
		System.out.println("Student saved ho gya ji!!!!!!!!!!!!!");
		ses.close();
		sf.close();
	}

}
