package com.ata.dao;

import java.util.ArrayList;

import com.ata.bean.DriverBean;

public class DriverDAOImpl implements DriverDAO {

	@Override
	public String createDriver(DriverBean driverbean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int deleteDriver(ArrayList<String> DriverList) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean updateDriver(DriverBean driverbean) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public DriverBean findByID(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<DriverBean> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int generateDriverId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean setdriverstatus(DriverBean driverBean, String driverid) {
		// TODO Auto-generated method stub
		return false;
	}

}
