package com.ata.dao;

import java.util.ArrayList;

import com.ata.bean.CredentialsBean;

public class CredentialsDAOImpl implements CredentialsDAO {

	@Override
	public String createCredentials(CredentialsBean credentialsBean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int deleteCredentials(ArrayList<String> CredentialsList) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean updateCredentials(CredentialsBean credentialsBean) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public CredentialsBean findByID(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<CredentialsBean> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
