package com.ata.main;



import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


import com.ata.bean.CredentialsBean;
import com.ata.bean.CreditCardCredentialsBean;
import com.ata.bean.ProfileBean;
import com.ata.bean.ReservationBean;

public class AtaMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*SessionFactory sf=new Configuration().configure().buildSessionFactory();
		Session ses=sf.openSession();
		Transaction tx=ses.beginTransaction();
		CredentialsBean cb=new CredentialsBean("Gitesh@123", "A", 1);
		cb.setUserID("YM113");
		
		System.out.println("*********************************");
		ProfileBean pb=new ProfileBean("Abhishek", "Kumar", new Date(), "Male", "Escort's", "FBD", "city", "state", "pincod", "mobileNo", "emailID");
		pb.setUserID("YM113");
		pb.setCredentialsBean(cb);
		
		ses.save(pb);
		cb.setProflieBean(pb);
		ses.save(pb);
		
		CreditCardCredentialsBean cc=new CreditCardCredentialsBean(new Date(), new Date(), 1422.0, cb);
		cc.setCreditCardNum("asksjd");
		ses.save(cc);
		
		
		ReservationBean r=new ReservationBean();
		
		ses.save(pb);
		ses.save(pb);
		ses.save(cc);
		ses.save(r);
		tx.commit();
		ses.close();*/
		
/*		CredentialsBean cb=new CredentialsBean();
		ReservationBean r=new ReservationBean();
		ses.save(cb);
		ses.save(r);
		*/
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session ses =sf.openSession();
		Transaction tr = ses.beginTransaction();
		CredentialsBean c = new CredentialsBean("A101", "1234", "a", 1);
		ses.save(c);
		ProfileBean pb = new ProfileBean(c, "Tarun", "Tarun", new Date(), "M", "Tarun", "Tarun", "Tarun", "Tarun", "Tarun", "Tarun", "Tarun");
		//ReservationBean r = new ReservationBean(reservationID, credentials, route, bookingDate, journeyDate, vehicle, driver, bookingStatus, totalFare, boardingPoint, dropPoint);
		
		ses.save(pb);
		tr.commit();
		ses.close();
		
	}

}
