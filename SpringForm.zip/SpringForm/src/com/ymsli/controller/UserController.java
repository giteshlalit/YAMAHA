package com.ymsli.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ymsli.bean.UserBean;
import com.ymsli.dao.UserDao;

@Controller
public class UserController {
	@Autowired
UserDao u;	
	@RequestMapping("newUser")
	public String newUserPage(Model m) {
		m.addAttribute("userBean",new UserBean());
		return "reg";
	}
	
	@ModelAttribute("countries")
	public List<String> initializeCountry(){
		List<String> li = new ArrayList<String>();
		li.add("India");
		li.add("USA");
		li.add("Canada");
		li.add("UK");
		li.add("Japan");		
		return li;
	}
	
	@ModelAttribute("languages")
	public List<String> initializeLanguage(){
		List<String> li = new ArrayList<String>();
		li.add("Hindi");
		li.add("English");
		li.add("Punjabi");
		li.add("Tamil");
		return li;
	}
	
	@RequestMapping("addUser")
	public String createUser(Model m,@Valid UserBean user,BindingResult br)
	{
		//m.addAttribute("success","Dear"+user+"!you are registered");
		if(br.hasErrors())
		{
			return "reg";
		}
		else
		{	
		m.addAttribute("success",user);
		String result=u.createUser(user);
		System.out.println(result);
		return "success";
		}
	}
		@ModelAttribute("qualifications")
	public List<String> initializeQualification(){
		List<String> li = new ArrayList<String>();
		li.add("Graduate");
		li.add("PostGraduate");
		li.add("Doctorate");
		return li;
	}
}

