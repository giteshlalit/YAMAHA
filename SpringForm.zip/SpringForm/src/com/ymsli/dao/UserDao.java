package com.ymsli.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ymsli.bean.UserBean;



@Repository
public class UserDao {
	@Autowired
	DataSource  dataSource;
	
	JdbcTemplate jTemplate;
/*	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		
	}
	*/
	
	public String createUser(UserBean u) {
	jTemplate=new JdbcTemplate(dataSource);
		String sql="insert into user2 values(?,?,?,?,?)";
		
		/*int result=jTemplate.update(sql, u.getName(),u.getSex(),u.getDob(),u.getEmail(),u.getCountry(),u.getLanguage());*/
	
		int result=jTemplate.update(sql, u.getName(),u.getSex(),u.getDob(),u.getEmail(),u.getCountry(),u.getLanguage());
		if(result>0)
		return "User Created";
		else
		return "Failed";
	}
	
}
