package com.ata.service;

import java.util.ArrayList;
import java.util.Date;

import org.springframework.stereotype.Component;

import com.ata.bean.DriverBean;
import com.ata.bean.ReservationBean;
import com.ata.bean.RouteBean;
import com.ata.bean.VehicleBean;

@Component
public interface Administrator {

	String addVehicle( VehicleBean vehicleBean);
	int deleteVehicle(String deleteVehicle) ;
	VehicleBean viewVehicle(String id) ;
	boolean modifyVehicle(VehicleBean VehicleBean) ;
	
	String addDriver(DriverBean driverbean);
	int deleteDriver(String deleteDriver) ;
	boolean modifyDriver(DriverBean driverbean) ;
	boolean allotDriver(String reservationID,String driverID) ;
	
	String addRoute( RouteBean routeBean);
	int deleteRoute(String deleteRoute) ;
	boolean modifyRoute(RouteBean routeBean) ;
	RouteBean viewRoute(String id) ;
	
	ArrayList<ReservationBean> viewBookingDetails(Date journeyDate,String source,String destination);
	
	
}
