package com.ata.Controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


import com.ata.bean.CredentialsBean;
import com.ata.bean.DriverBean;
import com.ata.bean.ProfileBean;
import com.ata.bean.RouteBean;
import com.ata.dao.CredentialsDAO;
import com.ata.dao.ProfileBeanDAO;
import com.ata.service.Administrator;
import com.ata.util.User;



@Controller
@ComponentScan(basePackages = "com")
public class MyController {
	@Autowired
	Administrator ad;
	@Autowired
	User usr;
	@Autowired
	CredentialsDAO cd;
	@Autowired
	ProfileBeanDAO pd;

	
	@RequestMapping("newUser")
	public String newUserPage(Model m) {
		List<ProfileBean> pb=pd.findAll();
		m.addAttribute("list",pb);
		m.addAttribute("profileBean", new ProfileBean());
		return "reg";
	}

	@RequestMapping("addProfile")
	public String createProfile(@Valid @ModelAttribute("profileBean") ProfileBean profileBean, BindingResult br,
			Model m) {

		if (br.hasErrors()) {
			m.addAttribute("profileBean", profileBean);
			return "reg";
		} else {

			String result = usr.register(profileBean);
			System.out.println(result);

			
			List<ProfileBean> pb=pd.findAll();
			m.addAttribute("list",pb);
			m.addAttribute("success", result);
			return "reg";
		}

	}
	
	@RequestMapping("newDriver")
	public String newDriverPage(Model m) {

		m.addAttribute("driverBean", new DriverBean());
		return "driverReg";
	}
	
	
	@RequestMapping("addDriver")
	public String addDriver(@Valid @ModelAttribute("driverBean") DriverBean driverBean, BindingResult br,
			Model m) {

		if (br.hasErrors()) {
			m.addAttribute("driverBean", driverBean);
			return "driverReg";
		} else {

			String result = ad.addDriver(driverBean);
			System.out.println(result);

			m.addAttribute("success", result);
			return "driverReg";
		}

	}
	@RequestMapping("login")
	public String newLoginPage(Model m) {

		m.addAttribute("credentialsBean", new CredentialsBean());
		return "login";
	}
	@RequestMapping("loginDetails")
	public String loginUser(@Valid @ModelAttribute("credentialsBean") CredentialsBean credentialsBean,Model m,HttpSession session)
	{
		

		String s=usr.login(credentialsBean);
		if(s.equals("Login Success"))
		{	
			CredentialsBean c=cd.findByID(credentialsBean.getUserID());
			session.setAttribute("customer", c);
		/*	return "redirect:newUser";*/
			m.addAttribute("profileBean", new ProfileBean());
			List<ProfileBean> pb=pd.findAll();
			m.addAttribute("list",pb);
			return "reg";
		}
		else if(s.equals("Login Failed")) {
			m.addAttribute("loginmsg", s);
			return "login";
		}
		else return "login";
		
	}

	
	@RequestMapping("newRoute")
	public String newRoutePage(Model m) {

		m.addAttribute("routeBean", new RouteBean());
		return "routeReg";
	}
	
	
	@RequestMapping("addRoute")
	public String addRoute(@Valid @ModelAttribute("routeBean") RouteBean routeBean, BindingResult br,
			Model m) {

		if (br.hasErrors()) {
			m.addAttribute("routeBean", routeBean);
			return "routeReg";
		} else {

			String result = ad.addRoute(routeBean);
			System.out.println(result);

			m.addAttribute("success", result);
			return "routeReg";
		}

	}
	
	
}
