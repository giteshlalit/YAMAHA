package com.ata.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.ata.bean.CredentialsBean;
import com.ata.bean.ReservationBean;

public class AtaMain {
	
	public static void main(String[] args) {
			SessionFactory sf=new Configuration().configure().buildSessionFactory();
			Session ses=sf.openSession();
			Transaction tx=ses.beginTransaction();
			
			CredentialsBean cb=new CredentialsBean("1234", "A", 1);
			ReservationBean r=new ReservationBean();
			
			ses.save(cb);
			ses.save(r);
			tx.commit();
			ses.close();

		
	}

}
