package com.ata.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.eclipse.jdt.internal.compiler.ast.FalseLiteral;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="ATA_TBL_DRIVER")

public class DriverBean {

	@Id
	@SequenceGenerator(name="seq",sequenceName="ata_seq_driverId")        
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
	@Column(length=6)
	private long driverID;
	@Column(length=25,nullable=false)
	@NotEmpty
	private String name;
	@NotEmpty
	@Column(length=30,nullable=false)
	
	private String street;
	@NotEmpty
	@Column(length=15,nullable=false)
	private String location;
	@NotEmpty
	@Column(length=15)
	private String city;
	@NotEmpty
	@Column(length=15)
	private String state;
	@Column(length=6)
	@NotEmpty
	private String pincode;
	@Column(length=10)
	@NotEmpty
	private String mobileNo;
	@Column(length=20,unique=true)
	
	private String licenseNumber;

	public DriverBean() {
	}

	public DriverBean(long driverID, String name, String street, String location, String city, String state,
			String pincode, String mobileNo, String licenseNumber) {
		super();
		this.driverID = driverID;
		this.name = name;
		this.street = street;
		this.location = location;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.mobileNo = mobileNo;
		this.licenseNumber = licenseNumber;
	}

	public long getDriverID() {
		return driverID;
	}

	public void setDriverID(long driverID) {
		this.driverID = driverID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getLicenseNumber() {
		return licenseNumber;
	}

	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

}
