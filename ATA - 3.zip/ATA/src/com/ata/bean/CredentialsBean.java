package com.ata.bean;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="ATA_TBL_USER_CREDENTIALS")
public class CredentialsBean {
	@Id
	@SequenceGenerator(name="seq",sequenceName="ata_seq_userId")        
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
	private long userID;
	@NotEmpty
	private String password;
	@NotEmpty
	private String userType;
	@NotNull
	private int loginStatus;

	


	/*@PrimaryKeyJoinColumn
	@OneToOne(cascade = CascadeType.ALL)
	private ProfileBean proflieBean;
*/
	public CredentialsBean() {
	}



	public CredentialsBean(/*long userID,*/ String password, String userType, int loginStatus) {
		super();
/*		this.userID = userID;*/
		this.password = password;
		this.userType = userType;
		this.loginStatus = loginStatus;
	
		
	}

	public long getUserID() {
		return userID;
	}

	public void setUserID(long userID) {
		this.userID = userID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public int getLoginStatus() {
		return loginStatus;
	}

	public void setLoginStatus(int loginStatus) {
		this.loginStatus = loginStatus;
	}


/*	public ProfileBean getProflieBean() {
		return proflieBean;
	}

	public void setProflieBean(ProfileBean proflieBean) {
		this.proflieBean = proflieBean;
	}*/

}
