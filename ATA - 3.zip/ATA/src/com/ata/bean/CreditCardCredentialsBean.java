package com.ata.bean;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.lang.NonNull;

@Entity
@Table(name="ATA_TBL_USER_CREDITCARD")
public class CreditCardCredentialsBean {

	@Id
	@Column(length=16)
	@NotEmpty
	private String creditCardNumber;
	@Column(length=7)
	@NonNull
	private Date validFrom;
	@NonNull
	@Column(length=7)
	private Date ValidTo;
	@NonNull
	private double creditBalance;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="USERID")
	private CredentialsBean credentials;
	

	public CredentialsBean getCredentials() {
		return credentials;
	}

	public void setCredentials(CredentialsBean credentials) {
		this.credentials = credentials;
	}

	public String getCreditCardNum() {
		return creditCardNumber;
	}

	public void setCreditCardNum(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	public Date getValidFrom() {
		return validFrom;
	}

	public void setValidFrom(Date validFrom) {
		this.validFrom = validFrom;
	}

	public Date getValidTo() {
		return ValidTo;
	}

	public void setValidTo(Date validTo) {
		ValidTo = validTo;
	}

	public double getCreditBalance() {
		return creditBalance;
	}

	public void setCreditBalance(double creditBalance) {
		this.creditBalance = creditBalance;
	}

	public CreditCardCredentialsBean( Date validFrom, Date validTo, double creditBalance,CredentialsBean credentials) {
		super();

		this.validFrom = validFrom;
		this.ValidTo = validTo;
		this.creditBalance = creditBalance;
		this.credentials=credentials;
	}

	public CreditCardCredentialsBean() {
		super();
	}



}
