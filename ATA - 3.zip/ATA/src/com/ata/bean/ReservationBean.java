package com.ata.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="ATA_TBL_RESERVATION")
public class ReservationBean {

	@Id
	@SequenceGenerator(name="seq",sequenceName="ata_seq_reservationId")        
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
	@Column(length = 6)
	private long reservationID;
	
	@OneToOne
	@JoinColumn(name="USERID")
	private CredentialsBean credentials;
	@OneToOne
	@JoinColumn(name="ROUTEID")
	private RouteBean route;
	@NotNull
	
	private String bookingDate;
	@NotNull
	private String journeyDate;
	@OneToOne
	@JoinColumn(name="VEHICLEID")
	private VehicleBean vehicle;
	@OneToOne
	@JoinColumn(name="DRIVERID")
	private DriverBean driver;
	@NotEmpty
	@Column(length = 20)
	private String bookingStatus;
	@NotNull
	@Column(length = 10)
	private double totalFare;
	@NotEmpty
	@Column(length = 30)
	private String boardingPoint;
	@NotEmpty
	@Column(length = 30)
	private String dropPoint;

	public ReservationBean(long reservationID, CredentialsBean credentials, RouteBean route, String bookingDate,
			String journeyDate, VehicleBean vehicle, DriverBean driver, String bookingStatus, double totalFare,
			String boardingPoint, String dropPoint) {
		super();
		this.reservationID = reservationID;
		this.credentials = credentials;
		this.route = route;
		this.bookingDate = bookingDate;
		this.journeyDate = journeyDate;
		this.vehicle = vehicle;
		this.driver = driver;
		this.bookingStatus = bookingStatus;
		this.totalFare = totalFare;
		this.boardingPoint = boardingPoint;
		this.dropPoint = dropPoint;
	}

	public ReservationBean() {
	}

	public long getReservationID() {
		return reservationID;
	}

	public void setReservationID(long reservationID) {
		this.reservationID = reservationID;
	}

	public CredentialsBean getCredentials() {
		return credentials;
	}

	public void setCredentials(CredentialsBean credentials) {
		this.credentials = credentials;
	}

	public RouteBean getRoute() {
		return route;
	}

	public void setRoute(RouteBean route) {
		this.route = route;
	}

	public String getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	public String getJourneyDate() {
		return journeyDate;
	}

	public void setJourneyDate(String journeyDate) {
		this.journeyDate = journeyDate;
	}

	public VehicleBean getVehicle() {
		return vehicle;
	}

	public void setVehicle(VehicleBean vehicle) {
		this.vehicle = vehicle;
	}

	public DriverBean getDriver() {
		return driver;
	}

	public void setDriver(DriverBean driver) {
		this.driver = driver;
	}

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public double getTotalFare() {
		return totalFare;
	}

	public void setTotalFare(double totalFare) {
		this.totalFare = totalFare;
	}

	public String getBoardingPoint() {
		return boardingPoint;
	}

	public void setBoardingPoint(String boardingPoint) {
		this.boardingPoint = boardingPoint;
	}

	public String getDropPoint() {
		return dropPoint;
	}

	public void setDropPoint(String dropPoint) {
		this.dropPoint = dropPoint;
	}

}
