package com.ata.dao;

import java.util.ArrayList;
import java.util.List;

import com.ata.bean.CredentialsBean;

public interface CredentialsDAO 
{
	String createCredentials( CredentialsBean credentialsBean);
	int deleteCredentials(String deleteCredentials) ;
	boolean updateCredentials(CredentialsBean credentialsBean) ;
	CredentialsBean findByID(long l) ;
	List<CredentialsBean> findAll();

}