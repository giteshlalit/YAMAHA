package com.ata.dao;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Repository;

import com.ata.bean.RouteBean;

@Repository
@ComponentScan(basePackages="com")
public class RouteDaoImpl implements RouteDAO{
	@Autowired
	SessionFactory sf;
	@Override
	public String createRoute(RouteBean routeBean) {
		Session ses=sf.getCurrentSession();

		ses.save(routeBean);
		return "Route Created with id:"+routeBean.getRouteID();
	}

	@Override
	public int deleteRoute(String deleteRoute) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean updateRoute(RouteBean routeBean) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public RouteBean findByID(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<RouteBean> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int generateRouteId() {
		// TODO Auto-generated method stub
		return 0;
	}

}
