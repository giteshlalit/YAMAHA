package com.ata.dao;

import java.util.ArrayList;

import com.ata.bean.RouteBean;

public interface RouteDAO {
	String createRoute( RouteBean routeBean);
	int deleteRoute(String deleteRoute) ;
	boolean updateRoute(RouteBean routeBean) ;
	RouteBean findByID(String id) ;
	ArrayList<RouteBean> findAll();
	int generateRouteId();

}
