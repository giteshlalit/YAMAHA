package com.ata.dao;

import java.util.ArrayList;

import com.ata.bean.VehicleBean;

public interface VehicleDAO {
	String createVehicle( VehicleBean vehicleBean);
	int deleteVehicle(String deleteVehicle) ;
	boolean updateVehicle(VehicleBean VehicleBean) ;
	VehicleBean findByID(String id) ;
	ArrayList<VehicleBean> findAll();
	public ArrayList<VehicleBean> findAll(int noOfSeats) ;
	public ArrayList<VehicleBean> findAll(String vehicleType);
	int generateVehicleId();
	int getTotalSeats(String vehicleID);


}
