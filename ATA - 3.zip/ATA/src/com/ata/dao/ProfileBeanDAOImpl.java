package com.ata.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ata.bean.CredentialsBean;
import com.ata.bean.ProfileBean;

@Repository
@ComponentScan(basePackages="com")
@Transactional
public class ProfileBeanDAOImpl implements ProfileBeanDAO {
@Autowired
	SessionFactory sf;
	@Override
	public String createProfileBean(ProfileBean pb) {
		Session ses=sf.getCurrentSession();
		pb.getCredentialsBean().setLoginStatus(0);
		pb.getCredentialsBean().setUserType("C");
		ses.save(pb);
		return "Customer Created with userid:"+pb.getUserID();
		
	}

	

	@Override
	public boolean updateProfileBean(ProfileBean pb) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ProfileBean findByID(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ProfileBean> findAll() {
		Session ses=sf.getCurrentSession();
		Query q=ses.createQuery("from ProfileBean c");
	
		 List<ProfileBean>	li=q.getResultList();
			return li;

	}

	@Override
	public int generateUserId() {
		// TODO Auto-generated method stub
		return 0;
	}



	@Override
	public int deleteProfileBean(String deleteProfile) {
		// TODO Auto-generated method stub
		return 0;
	}

}
