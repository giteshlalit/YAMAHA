package com.ata.util;

public class PaymentImpl implements Payment{

	@Override
	public boolean findByCardNumber(String userID, String cardNumber) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String process(Payment payment) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
