package com.ata.util;



import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.ata.bean.CredentialsBean;
import com.ata.bean.ProfileBean;
import com.ata.dao.CredentialsDAO;
import com.ata.dao.ProfileBeanDAO;
@Component

@Transactional
@ComponentScan(basePackages="com")
public class UserImpl implements User{

	@Autowired
	ProfileBeanDAO pd;
	
	@Autowired
	Authentication au;
	@Autowired
	CredentialsDAO cd;
	@Override
	public String login(CredentialsBean credentialsBean) {
		
		CredentialsBean c=cd.findByID(credentialsBean.getUserID());
		if(c==null)
			return "ID NOT FOUND";
		else
		{
		boolean b=au.authenticate(credentialsBean);
		if(b==true)
		return "Login Success";
		else
			return "Login Failed";
	
		}
		}

	@Override
	public boolean logout(String userId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String changePassword(CredentialsBean credentialsBean, String newPassword) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String register(ProfileBean profileBean) {
		return pd.createProfileBean(profileBean);
	}

}
