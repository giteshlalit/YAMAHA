package com.bean;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Employee {
@Value("${empid}")
private int empid;
@Value("${name}")
private String name;
private Set<String> phone;
@Autowired

private Address address;
public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}


/*public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}*/

/*public List<String> getPhone() {
	return phone;
}
public void setPhone(List<String> phone) {
	this.phone = phone;
}*/


public void printEmployee()
{
	System.out.println("Empid:"+empid);
	System.out.println("EmpName:"+name);
	System.out.println("City:"+address.getCity());
	System.out.println("Country:"+address.getCountry());
	System.out.println("Phone:"+phone);
}
public Set<String> getPhone() {
	return phone;
}
public void setPhone(Set<String> phone) {
	this.phone = phone;
}
/*public void initialize()
{
	System.out.println("Bean Created!!!!");
}
public void destroy()
{
	System.out.println("Bean Destroyed!!!!");
}*/
/*@Override
public void destroy() throws Exception {
	// TODO Auto-generated method stub
	System.out.println("Employee Destroyed");
}
@Override
public void afterPropertiesSet() throws Exception {
	// TODO Auto-generated method stub
	System.out.println("Employee Initialized");
}*/
}
