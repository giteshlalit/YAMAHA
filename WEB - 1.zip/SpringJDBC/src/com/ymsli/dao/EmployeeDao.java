package com.ymsli.dao;

import com.ymsli.bean.Employee;

public interface EmployeeDao {
public String createEmployee(Employee e);
}
