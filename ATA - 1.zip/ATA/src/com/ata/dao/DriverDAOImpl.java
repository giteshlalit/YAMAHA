package com.ata.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Repository;

import com.ata.bean.DriverBean;


@Repository
@ComponentScan(basePackages="com")
public class DriverDAOImpl implements DriverDAO {
	@Autowired
	SessionFactory sf;
	@Override
	public String createDriver(DriverBean driverbean) {
		// TODO Auto-generated method stub

		Session ses=sf.getCurrentSession();

		ses.save(driverbean);
		return "Driver Created with userid:"+driverbean.getDriverID();
	}

	

	@Override
	public boolean updateDriver(DriverBean driverbean) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public DriverBean findByID(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<DriverBean> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int generateDriverId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean setdriverstatus(DriverBean driverBean, String driverid) {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public int deleteDriver(String deleteDriver) {
		// TODO Auto-generated method stub
		return 0;
	}

}
