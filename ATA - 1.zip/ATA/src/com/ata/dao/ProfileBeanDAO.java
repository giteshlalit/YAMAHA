package com.ata.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.ata.bean.ProfileBean;

@Repository
public interface ProfileBeanDAO {
	String createProfileBean(ProfileBean pb);
	int deleteProfileBean(String deleteProfile); 
	boolean updateProfileBean(ProfileBean pb); 
	ProfileBean findByID(String id);
	ArrayList<ProfileBean> findAll();
	public int generateUserId();

}
