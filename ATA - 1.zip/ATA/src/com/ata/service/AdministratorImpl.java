package com.ata.service;

import java.util.ArrayList;
import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ata.bean.DriverBean;
import com.ata.bean.ReservationBean;
import com.ata.bean.RouteBean;
import com.ata.bean.VehicleBean;
import com.ata.dao.DriverDAO;

@Component
@Transactional
public class AdministratorImpl implements Administrator {
@Autowired
	DriverDAO dd;
	@Override
	public String addVehicle(VehicleBean vehicleBean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int deleteVehicle(String deleteVehicle) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public VehicleBean viewVehicle(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean modifyVehicle(VehicleBean VehicleBean) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String addDriver(DriverBean driverbean) {
		// TODO Auto-generated method stub
		return dd.createDriver(driverbean);
	}

	@Override
	public int deleteDriver(String deleteDriver) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean modifyDriver(DriverBean driverbean) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean allotDriver(String reservationID, String driverID) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String addRoute(RouteBean routeBean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int deleteRoute(String deleteRoute) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean modifyRoute(RouteBean routeBean) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public RouteBean viewRoute(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<ReservationBean> viewBookingDetails(Date journeyDate, String source, String destination) {
		// TODO Auto-generated method stub
		return null;
	}

}
