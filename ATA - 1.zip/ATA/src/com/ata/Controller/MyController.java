package com.ata.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ata.bean.DriverBean;
import com.ata.bean.ProfileBean;

import com.ata.service.Administrator;
import com.ata.util.User;

@Controller
@ComponentScan(basePackages = "com")
public class MyController {
	@Autowired
	Administrator ad;
	@Autowired
	User usr;

	@RequestMapping("newUser")
	public String newUserPage(Model m) {

		m.addAttribute("profileBean", new ProfileBean());
		return "reg";
	}
	/*
	 * @RequestMapping("login") public String newLoginPage(Model m) { List<Employee>
	 * e=ed.getAllEmployee(); m.addAttribute("list",e);
	 * m.addAttribute("employeeBean",new Employee()); return "login"; }
	 */

	@RequestMapping("addProfile")
	public String createProfile(@Valid @ModelAttribute("profileBean") ProfileBean profileBean, BindingResult br,
			Model m) {

		if (br.hasErrors()) {
			m.addAttribute("profileBean", profileBean);
			return "reg";
		} else {

			String result = usr.register(profileBean);
			System.out.println(result);

			m.addAttribute("success", result);
			return "success";
		}

	}
	
	@RequestMapping("newDriver")
	public String newDriverPage(Model m) {

		m.addAttribute("driverBean", new DriverBean());
		return "driverReg";
	}
	
	
	@RequestMapping("addDriver")
	public String addDriver(@Valid @ModelAttribute("driverBean") DriverBean driverBean, BindingResult br,
			Model m) {

		if (br.hasErrors()) {
			m.addAttribute("driverBean", driverBean);
			return "driverReg";
		} else {

			String result = ad.addDriver(driverBean);
			System.out.println(result);

			m.addAttribute("success", result);
			return "driverReg";
		}

	}
	
}
