package com.ata.util;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import com.ata.bean.CredentialsBean;
import com.ata.bean.ProfileBean;
import com.ata.dao.ProfileBeanDAO;
@Component
@Transactional
@ComponentScan(basePackages="com")
public class UserImpl implements User{

	@Autowired
	ProfileBeanDAO pd;
	@Override
	public String login(CredentialsBean credentialsBean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean logout(String userId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String changePassword(CredentialsBean credentialsBean, String newPassword) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String register(ProfileBean profileBean) {
		return pd.createProfileBean(profileBean);
	}

}
