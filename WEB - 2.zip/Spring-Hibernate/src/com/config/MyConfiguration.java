package com.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@PropertySource("classpath:resources/jdbc.properties")
@ComponentScan("com")
public class MyConfiguration {
	@Autowired
	Environment env;
	@Bean
	public DataSource dataSource()
	{
	DriverManagerDataSource ds=new DriverManagerDataSource();
	ds.setDriverClassName(env.getRequiredProperty("jdbc.driver"));
	ds.setUrl(env.getRequiredProperty("jdbc.url"));
	ds.setUsername(env.getRequiredProperty("jdbc.username"));
	ds.setPassword(env.getRequiredProperty("jdbc.password"));
	return ds;
	}
	
	@Bean
	public LocalSessionFactoryBean getSessionFactory()
	{
		LocalSessionFactoryBean ls=new LocalSessionFactoryBean();
		ls.setDataSource(dataSource());
		ls.setPackagesToScan(env.getRequiredProperty("setPackage"));
		Properties hibernateProperties=new Properties();
		hibernateProperties.put("hibernate.dialect",env.getRequiredProperty("dialect"));
		hibernateProperties.put("hibernate.hbm2ddl.auto",env.getRequiredProperty("hbm2ddl"));
		hibernateProperties.put("show_sql",env.getRequiredProperty("show_sql"));
		ls.setHibernateProperties(hibernateProperties);
		
		return ls;
	}
	
	@Bean

	public HibernateTransactionManager getHibernateTransactionManager(LocalSessionFactoryBean ls)
	{
		HibernateTransactionManager htm=new HibernateTransactionManager();
		htm.setSessionFactory(getSessionFactory().getObject());
	
		return htm;
	
}
}
