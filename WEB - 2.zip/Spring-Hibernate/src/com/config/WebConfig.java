package com.config;

public class WebConfig {

}
