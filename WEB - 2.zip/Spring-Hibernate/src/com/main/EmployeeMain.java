package com.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ymsli.bean.Employee;
import com.ymsli.dao.EmployeeDao;

public class EmployeeMain {

	public static void main(String[] args) {
/*		Employee emp=new Employee("Aa180", "Aakash", 22, 25000, "meerut");
		ApplicationContext ctx=new ClassPathXmlApplicationContext("Bean.xml");
		EmployeeDao ed=(EmployeeDao)ctx.getBean("edao");
		System.out.println(ed.createEmployee(emp));
		*/
		
		AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext();
		ctx.scan("com.config");
		ctx.refresh();
		EmployeeDao ed=(EmployeeDao)ctx.getBean("edao");
		Employee emp=new Employee("Aa183", "Aakash", 22, 25000, "meerut");
		System.out.println(ed.createEmployee(emp));
		
	}

}
