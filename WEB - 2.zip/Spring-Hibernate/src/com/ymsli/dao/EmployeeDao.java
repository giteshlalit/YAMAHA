package com.ymsli.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.ymsli.bean.Employee;

@Repository("edao")
@EnableTransactionManagement
public class EmployeeDao {
	@Autowired
	SessionFactory sessionFactory;

	@Transactional

	public String createEmployee(Employee emp) {
		Session ses = sessionFactory.getCurrentSession();
		ses.save(emp);
		return "Employee Created";

	}
	
	
}
