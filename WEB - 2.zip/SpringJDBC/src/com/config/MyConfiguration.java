 package com.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;


@Configuration
@PropertySource("classpath:resources/jdbc.properties")
@ComponentScan("com")

public class MyConfiguration {
	@Autowired
	private Environment environment;
	@Bean
	public DataSource dataSource()
	{
	DriverManagerDataSource ds=new DriverManagerDataSource();
/*	ds.setDriverClassName("org.postgresql.Driver");
	ds.setUrl("jdbc:postgresql://localhost:5432/postgres");
	ds.setUsername("postgres");
	ds.setPassword("postgres")*/;
	
	ds.setDriverClassName(environment.getRequiredProperty("jdbc.driver"));
	ds.setUrl(environment.getRequiredProperty("jdbc.url"));
	ds.setUsername(environment.getRequiredProperty("jdbc.username"));
	ds.setPassword(environment.getRequiredProperty("jdbc.password"));
	
	return ds;
	}
	
	@Bean
	public JdbcTemplate getJdbcTemplate(DataSource ds)
	{
		JdbcTemplate jt=new JdbcTemplate(ds);
		return jt;
	}
}
