package com.ymsli.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ymsli.bean.Employee;

public class EmployeeMapper implements RowMapper<Employee>{

	@Override
	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		Employee e=new Employee();
		e.setEmpid(rs.getString(0));
		e.setName(rs.getString(1));
		e.setAge(rs.getInt(2));
		e.setSalary(rs.getDouble(3));
		e.setAddress(rs.getString(5));
		return e;
	}

}
