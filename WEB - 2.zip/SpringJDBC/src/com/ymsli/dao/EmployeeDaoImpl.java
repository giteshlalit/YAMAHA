package com.ymsli.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.ymsli.bean.Employee;

@Repository(value="daoImpl")
public class EmployeeDaoImpl implements EmployeeDao{
	@Autowired
	JdbcTemplate jTemplate;
	

/*	DataSource dataSource;
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jTemplate=new JdbcTemplate(dataSource);
	}
*/
	
	@Override
	public String createEmployee(Employee e) {
		String sql="insert into Employee values(?,?,?,?,?)";
	
		int result=jTemplate.update(sql, e.getEmpid(),e.getName(),e.getAge(),e.getSalary(),e.getAddress());
		if(result>0)
		return "Employee Created";
		else
		return "Failed";
	}


	@Override
	public List<Employee> getAllEmplyoees() {
		String sql="Select * from employee";
		RowMapper<Employee> rm=(rs,n)->{
			Employee emp=new Employee();
			emp.setEmpid(rs.getString(1));
			emp.setName(rs.getString(2));
			emp.setAge(rs.getInt(3));
			emp.setSalary(rs.getDouble(4));
			emp.setAddress(rs.getString(5));
			return emp;
		};
			List<Employee> li=jTemplate.query(sql, rm);
		return li;
	}

}
