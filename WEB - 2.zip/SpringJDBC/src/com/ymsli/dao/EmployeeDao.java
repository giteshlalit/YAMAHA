package com.ymsli.dao;

import java.util.List;

import com.ymsli.bean.Employee;

public interface EmployeeDao {
public String createEmployee(Employee e);
public List<Employee> getAllEmplyoees();
}
