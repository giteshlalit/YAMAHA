package com.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ymsli.bean.Employee;
import com.ymsli.dao.EmployeeDao;
import com.ymsli.dao.EmployeeDaoImpl;

public class EmployeeMain {

	public static void main(String[] args) {
/*		ApplicationContext ctx=new ClassPathXmlApplicationContext("");
		EmployeeDao ed=(EmployeeDaoImpl)ctx.getBean("daoImpl");
		String result=ed.createEmployee(new Employee("Ku121", "Kaushal", 21, 50000, "ddn"));
		System.out.println(result);*/

		AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext();
		ctx.scan("com.config");
		ctx.refresh();
		EmployeeDao ed=(EmployeeDaoImpl)ctx.getBean("daoImpl");
/*		String result=ed.createEmployee(new Employee("Ku122", "Kaushal", 21, 50000, "ddn"));
		System.out.println(result);*/
		List<Employee> li=ed.getAllEmplyoees();
		li.forEach(a->{System.out.println(a.getEmpid()+"\t"+a.getName()+"\t"+a.getSalary());});
		
	}

}
