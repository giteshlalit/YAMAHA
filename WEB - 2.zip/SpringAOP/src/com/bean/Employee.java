package com.bean;

public class Employee {
	private String empid;
	private String name;
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Employee(String empid, String name) {
		super();
		this.empid = empid;
		this.name = name;
	}
	public Employee() {}
}
