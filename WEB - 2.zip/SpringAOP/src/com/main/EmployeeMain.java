package com.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bean.Employee;
import com.dao.EmployeeDao;

public class EmployeeMain {

	public static void main(String[] args) {
		Employee e=new Employee("1001", "Gitz");
		ApplicationContext ctx=new ClassPathXmlApplicationContext("Bean.xml");
		EmployeeDao ed=ctx.getBean(EmployeeDao.class);
	//	ed.createEmployee(e);
		System.out.println("----------------------------------");
	//	ed.deleteEmployee("10011");
		
		
		
		ed.getAllEmployee();
	
	}

}
