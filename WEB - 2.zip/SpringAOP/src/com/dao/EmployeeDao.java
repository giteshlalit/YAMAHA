package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.bean.Employee;

@Component
public class EmployeeDao {
	List<Employee> li = new ArrayList<Employee>();

	public void createEmployee(Employee e)

	{
		li.add(e);
		System.out.println("Employee Added");
	}

	public List<Employee> getAllEmployee()

	{
		System.out.println("------------IN GET ALL EMPLOYEE------------------");
		return li;
	}
	
	public void deleteEmployee(String empid)
	{
		System.out.println("======================Employee Deleted=====================");
	}

	
	
	
}
