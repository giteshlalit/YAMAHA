package com.aop;

import java.util.Date;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class EmployeeAop {

	/*
	 * @Before("execution(* com.dao.EmployeeDao.*(..))") // will execute before
	 * calling any method of employeeDAO public void logMe(JoinPoint jp) {
	 * System.out.println("Before Method called-->" + jp.getSignature().getName());
	 * System.out.println("Method Called At:" + new Date()); }
	 * 
	 * 
	 * 
	 * @After("execution(* com.dao.EmployeeDao.*(..))") // will execute after
	 * calling any method of employeeDAO public void logMe1(JoinPoint jp) {
	 * System.out.println("After Method called-->" + jp.getSignature().getName());
	 * System.out.println("Method Called At:" + new Date()); }
	 */

	@Around("execution(* com.dao.EmployeeDao.*(..))") // will execute before calling any method of
																	// employeeDAO
	public void logMe(ProceedingJoinPoint jp) throws Throwable {
		Object ob[] = jp.getArgs();
		String eid = (String) ob[0]; // Behind the Scene Validation

		if (eid.length() < 5) {
			System.out.println("Invalid Entry");

		} else {

			System.out.println("Before Method called-->" + jp.getSignature().getName());
			System.out.println("Method Called At:" + new Date());
			System.out.println("Parameter------->" + eid);
			jp.proceed();
			System.out.println("-------------After Method Called------------------");

		}
	}
	
	@AfterThrowing( pointcut="execution(* com.dao.EmployeeDao.*(..))",throwing="ex")
	public void message(Exception ex)
	{
		System.out.println("Exception!!!!!!!!!"+ex);
		
		
	}
	/*
	 * @After("execution(* com.dao.EmployeeDao.deleteEmployee(..))") // will execute
	 * after calling any method of // employeeDAO public void logMe1(JoinPoint jp) {
	 * System.out.println("After Method called-->" + jp.getSignature().getName());
	 * System.out.println("Method Called At:" + new Date()); }
	 */

}
