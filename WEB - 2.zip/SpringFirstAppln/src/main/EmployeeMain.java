package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bean.Employee;
import com.bean.HelloWorld;

public class EmployeeMain {

	public static void main(String[] args) {
/*	Employee e=new Employee();
	e.printEmployee();*/
		ApplicationContext ctx=new ClassPathXmlApplicationContext("Bean.xml");	
		Employee e=(Employee)ctx.getBean("employee");
		e.printEmployee();
/*		e=null;						//this line just make it eligible to be destroyed!!!,will not print emp destroyed
		Employee e1=(Employee)ctx.getBean("emp");
		e1.printEmployee();*/
		
	}

}
