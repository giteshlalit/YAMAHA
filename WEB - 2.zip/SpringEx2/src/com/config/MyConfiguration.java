package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.bean.Employee;
import com.bean.Project;

@Configuration
@ComponentScan(basePackages="com")
public class MyConfiguration {
/*	
	@Bean(value="emp")
	public Employee getEmployee()
	{
		return new Employee();
	}
	
	@Bean
	public Project getProject()
	{
		return new Project();
	}
	*/
}
