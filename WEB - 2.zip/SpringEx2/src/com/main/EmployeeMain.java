package com.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.bean.Employee;

public class EmployeeMain {

	public static void main(String[] args) {
	
		AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext();
		ctx.scan("com.config");
		ctx.refresh();
		Employee e=(Employee)ctx.getBean("emp");
		System.out.println(e);
		Employee e1=(Employee)ctx.getBean("emp");
		System.out.println(e1);
		System.out.println(e.getProject().getPcode());

	}

}
