package com.bean;

import org.springframework.stereotype.Component;

@Component
public class Project {
private int pcode;
private String pname;
public int getPcode() {
	return pcode;
}
public void setPcode(int pcode) {
	this.pcode = pcode;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}

}
