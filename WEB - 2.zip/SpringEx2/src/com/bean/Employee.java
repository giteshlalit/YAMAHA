package com.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component(value="emp")
@Scope(value="prototype")
public class Employee {
private int empid;
private String name;

@Autowired
private Project project;
public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Project getProject() {
	return project;
}
public void setProject(Project project) {
	this.project = project;
}




}
